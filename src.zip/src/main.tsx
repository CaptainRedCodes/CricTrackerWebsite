import React, { createContext, useContext, useMemo, useState } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Link, Navigate, Route, Routes, useParams } from "react-router-dom";
import { Award, BarChart3, CalendarDays, Home, ShieldCheck, Swords, UploadCloud, Users } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Match, TrackerState } from "./types";
import { appendMatch, findDuplicateMatch, loadState, saveState } from "./lib/storage";
import { boundaryStats, dashboardStats, fieldingStats, matchTrend, mvpStats, playerBattingStats, playerBowlingStats, teamStats } from "./lib/stats";
import { extractPdfPages } from "./lib/pdf";
import { parseMatchFromPages } from "./lib/parser";
import "./styles.css";

const AppContext = createContext<{ state: TrackerState; addMatch: (match: Match) => void } | null>(null);

function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("Missing app context");
  return context;
}

function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState(loadState);
  const addMatch = (match: Match) => {
    const next = appendMatch(state, match);
    saveState(next);
    setState(next);
  };
  return <AppContext.Provider value={{ state, addMatch }}>{children}</AppContext.Provider>;
}

function Layout() {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <img src="/teamlogos/Hurricanes.png" alt="Hurricanes" />
          <div>
            <strong>SL Tracker</strong>
            <span>Hurricanes vs Dominators</span>
          </div>
          <img src="/teamlogos/dominators.png" alt="Dominators" />
        </div>
        <nav>
          <Link to="/"><Home size={20} /> Dashboard</Link>
          <Link to="/matches"><CalendarDays size={20} /> Matches</Link>
          <Link to="/players"><Users size={20} /> Players</Link>
          <Link to="/teams"><BarChart3 size={20} /> Teams</Link>
          <Link to="/upload"><UploadCloud size={20} /> Upload</Link>
        </nav>
      </aside>
      <main>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/matches" element={<Matches />} />
          <Route path="/matches/:id" element={<MatchDetail />} />
          <Route path="/players" element={<Players />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
    </div>
  );
}

function Dashboard() {
  const { state } = useApp();
  const stats = dashboardStats(state.matches);
  const trend = matchTrend(state.matches);
  const batting = playerBattingStats(state.matches).slice(0, 6);
  const bowling = playerBowlingStats(state.matches).slice(0, 6);
  const teams = teamStats(state.matches);

  return (
    <Page title="Dashboard" action={<Link className="button" to="/upload">Upload scorecard</Link>}>
      <section className="scoreHero">
        <div className="teamTile">
          <img src="/teamlogos/Hurricanes.png" alt="Hurricanes" />
          <strong>HURRICANES</strong>
          <span>{teams.find((team) => team.team === "HURRICANES")?.wins ?? 0} wins</span>
        </div>
        <div className="heroCenter">
          <span>Head to head</span>
          <strong>{stats.matchesPlayed} matches</strong>
          <p>{stats.latestMatch?.resultText ?? "Upload a scorecard to begin tracking the tournament."}</p>
        </div>
        <div className="teamTile">
          <img src="/teamlogos/dominators.png" alt="Dominators" />
          <strong>DOMINATORS</strong>
          <span>{teams.find((team) => team.team === "DOMINATORS")?.wins ?? 0} wins</span>
        </div>
      </section>

      <div className="summaryGrid rich">
        <Metric icon={<Swords size={22} />} label="Most runs" value={stats.topBatter?.name ?? "-"} sub={stats.topBatter ? `${stats.topBatter.runs} runs, SR ${stats.topBatter.strikeRate}` : ""} />
        <Metric icon={<ShieldCheck size={22} />} label="Most wickets" value={stats.topBowler?.name ?? "-"} sub={stats.topBowler ? `${stats.topBowler.wickets} wickets, Eco ${stats.topBowler.economy}` : ""} />
        <Metric icon={<Award size={22} />} label="MVP leader" value={stats.topMvp?.name ?? "-"} sub={stats.topMvp ? `${stats.topMvp.points} points` : ""} />
        <Metric icon={<Users size={22} />} label="Fielding impact" value={stats.topFielder?.name ?? "-"} sub={stats.topFielder ? `${stats.topFielder.total} catches/run-outs` : ""} />
      </div>

      <div className="dashboardGrid">
        <section className="panel wide">
          <h2>Runs By Match</h2>
          <div className="chart">
            <ResponsiveContainer>
              <LineChart data={trend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="HURRICANES" stroke="#1f7a8c" strokeWidth={3} connectNulls />
                <Line type="monotone" dataKey="DOMINATORS" stroke="#d97706" strokeWidth={3} connectNulls />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>
        <section className="panel">
          <h2>Top Run Scorers</h2>
          <MiniBars data={batting} labelKey="name" valueKey="runs" />
        </section>
        <section className="panel">
          <h2>Top Wicket Takers</h2>
          <MiniBars data={bowling} labelKey="name" valueKey="wickets" />
        </section>
        <section className="panel wide">
          <h2>Match Pressure</h2>
          <div className="chart">
            <ResponsiveContainer>
              <AreaChart data={trend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="extras" stroke="#b45309" fill="#fde68a" />
                <Area type="monotone" dataKey="wickets" stroke="#6b7280" fill="#d1d5db" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>
    </Page>
  );
}

function Matches() {
  const { state } = useApp();
  return (
    <Page title="Matches">
      <div className="list">
        {state.matches.map((match) => (
          <Link className="matchRow" to={`/matches/${match.id}`} key={match.id}>
            <div>
              <strong>{match.teamA} vs {match.teamB}</strong>
              <span>{match.matchDate} · {match.ground}</span>
            </div>
            <div className="scoreLine">{match.innings.map((i) => `${i.battingTeam} ${i.totalRuns}/${i.totalWickets}`).join("  |  ")}</div>
            <div>{match.resultText}</div>
          </Link>
        ))}
      </div>
    </Page>
  );
}

function MatchDetail() {
  const { id } = useParams();
  const { state } = useApp();
  const match = state.matches.find((item) => item.id === id);
  if (!match) return <Page title="Match not found"><p>No match found.</p></Page>;
  return (
    <Page title={`${match.teamA} vs ${match.teamB}`}>
      <section className="panel details">
        <div><strong>Date</strong><span>{match.matchDate} {match.matchTime}</span></div>
        <div><strong>Ground</strong><span>{match.ground}</span></div>
        <div><strong>Toss</strong><span>{match.tossWinner} {match.tossDecision}</span></div>
        <div><strong>Result</strong><span>{match.resultText}</span></div>
      </section>
      {match.innings.map((innings) => (
        <section className="panel" key={innings.id}>
          <h2>{innings.battingTeam} {innings.totalRuns}/{innings.totalWickets} <span>({innings.overs} Ov)</span></h2>
          <DataTable headers={["Batter", "Status", "R", "B", "4s", "6s", "SR"]} rows={innings.batting.map((row) => [row.playerNameRaw, row.dismissalRaw, row.runs, row.balls, row.fours, row.sixes, row.strikeRate])} />
          <p className="small">Extras: {innings.extrasTotal} · To bat: {innings.didNotBat.join(", ") || "-"}</p>
          <h3>Bowling</h3>
          <DataTable headers={["Bowler", "O", "M", "R", "W", "0s", "WD", "NB", "Eco"]} rows={innings.bowling.map((row) => [row.playerNameRaw, row.overs, row.maidens, row.runsConceded, row.wickets, row.dotBalls, row.wides, row.noballs, row.economy])} />
          <p className="small">Fall of wickets: {innings.fallOfWickets.map((fow) => `${fow.scoreAtFall}-${fow.wicketNumber} (${fow.batterOut}, ${fow.over} ov)`).join(", ") || "-"}</p>
        </section>
      ))}
    </Page>
  );
}

function Players() {
  const { state } = useApp();
  const [tab, setTab] = useState("runs");
  const batting = playerBattingStats(state.matches);
  const bowling = playerBowlingStats(state.matches);
  const mvp = mvpStats(state.matches);
  const fielding = fieldingStats(state.matches);
  const boundaries = boundaryStats(state.matches);
  const economy = [...bowling].sort((a, b) => Number(a.economy) - Number(b.economy));
  const average = [...batting].sort((a, b) => Number(b.average === "-" ? -1 : b.average) - Number(a.average === "-" ? -1 : a.average));

  const tabs = [
    { id: "runs", label: "Runs" },
    { id: "wickets", label: "Wickets" },
    { id: "mvp", label: "MVP" },
    { id: "fielding", label: "Catches/Run-outs" },
    { id: "boundaries", label: "4s & 6s" },
    { id: "economy", label: "Economy" },
    { id: "average", label: "Average" }
  ];

  return (
    <Page title="Player Stats">
      <div className="tabs" role="tablist" aria-label="Player stat categories">
        {tabs.map((item) => (
          <button className={tab === item.id ? "active" : ""} key={item.id} onClick={() => setTab(item.id)} type="button">
            {item.label}
          </button>
        ))}
      </div>
      {tab === "runs" && (
        <StatsPanel title="Most Runs" headers={["Player", "Inn", "Runs", "Avg", "SR", "HS", "4s", "6s"]} rows={batting.map((p) => [p.name, p.innings, p.runs, p.average, p.strikeRate, p.highScore, p.fours, p.sixes])} chartData={batting.slice(0, 8)} valueKey="runs" />
      )}
      {tab === "wickets" && (
        <StatsPanel title="Most Wickets" headers={["Player", "Overs", "Wkts", "Eco", "Avg", "SR", "Dots", "Best"]} rows={bowling.map((p) => [p.name, p.overs, p.wickets, p.economy, p.average, p.strikeRate, p.dotBalls, p.bestFigures])} chartData={bowling.slice(0, 8)} valueKey="wickets" />
      )}
      {tab === "mvp" && (
        <StatsPanel title="MVP Points" headers={["Player", "Points", "Runs", "Wickets", "Fielding", "Sixes", "Dots"]} rows={mvp.map((p) => [p.name, p.points, p.runs, p.wickets, p.fielding, p.sixes, p.dots])} chartData={mvp.slice(0, 8)} valueKey="points" />
      )}
      {tab === "fielding" && (
        <StatsPanel title="Catches And Run-outs" headers={["Player", "Total", "Catches", "Run-outs", "Stumpings"]} rows={fielding.map((p) => [p.name, p.total, p.catches, p.runOuts, p.stumpings])} chartData={fielding.slice(0, 8)} valueKey="total" />
      )}
      {tab === "boundaries" && (
        <StatsPanel title="Boundaries" headers={["Player", "Boundaries", "Boundary Runs", "4s", "6s", "Runs"]} rows={boundaries.map((p) => [p.name, p.boundaries, p.boundaryRuns, p.fours, p.sixes, p.runs])} chartData={boundaries.slice(0, 8)} valueKey="boundaries" />
      )}
      {tab === "economy" && (
        <StatsPanel title="Best Economy" headers={["Player", "Overs", "Eco", "Runs", "Wkts", "Dots", "WD", "NB"]} rows={economy.map((p) => [p.name, p.overs, p.economy, p.runsConceded, p.wickets, p.dotBalls, p.wides, p.noballs])} chartData={economy.slice(0, 8)} valueKey="economy" />
      )}
      {tab === "average" && (
        <StatsPanel title="Batting Average" headers={["Player", "Avg", "Runs", "Dismissals", "Not outs", "Inn", "SR"]} rows={average.map((p) => [p.name, p.average, p.runs, p.dismissals, p.notOuts, p.innings, p.strikeRate])} chartData={average.filter((p) => p.average !== "-").slice(0, 8)} valueKey="average" />
      )}
      <section className="panel mutedPanel">
        <h2>Complete Tables</h2>
        <p className="small">The tabs above show focused leaderboards. Full batting and bowling tables are kept here for quick checking.</p>
      </section>
      <section className="panel">
        <h2>Batting</h2>
        <DataTable headers={["Player", "Inn", "Runs", "Avg", "SR", "HS", "4s", "6s"]} rows={batting.map((p) => [p.name, p.innings, p.runs, p.average, p.strikeRate, p.highScore, p.fours, p.sixes])} />
      </section>
      <section className="panel">
        <h2>Bowling</h2>
        <DataTable headers={["Player", "Overs", "Wkts", "Eco", "Avg", "SR", "Dots", "Best"]} rows={bowling.map((p) => [p.name, p.overs, p.wickets, p.economy, p.average, p.strikeRate, p.dotBalls, p.bestFigures])} />
      </section>
    </Page>
  );
}

function StatsPanel({ title, headers, rows, chartData, valueKey }: { title: string; headers: string[]; rows: Array<Array<React.ReactNode>>; chartData: any[]; valueKey: string }) {
  return (
    <section className="panel">
      <h2>{title}</h2>
      <div className="statsSplit">
        <div className="chart compactChart">
          <ResponsiveContainer>
            <BarChart data={chartData} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" width={110} />
              <Tooltip />
              <Bar dataKey={valueKey} fill="#1f7a8c" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <DataTable headers={headers} rows={rows} />
      </div>
    </section>
  );
}

function MiniBars({ data, labelKey, valueKey }: { data: any[]; labelKey: string; valueKey: string }) {
  return (
    <div className="miniBars">
      {data.map((item) => {
        const max = Math.max(...data.map((entry) => Number(entry[valueKey]) || 0), 1);
        const value = Number(item[valueKey]) || 0;
        return (
          <div className="miniBar" key={item.playerId ?? item[labelKey]}>
            <div><strong>{item[labelKey]}</strong><span>{value}</span></div>
            <progress value={value} max={max} />
          </div>
        );
      })}
    </div>
  );
}

function Teams() {
  const { state } = useApp();
  const teams = teamStats(state.matches);
  const trend = state.matches.flatMap((match) => match.innings.map((innings) => ({
    name: `${match.matchDate} ${innings.battingTeam}`,
    runs: innings.totalRuns,
    team: innings.battingTeam
  }))).reverse();
  return (
    <Page title="Team Stats">
      <div className="summaryGrid">{teams.map((team) => <Metric key={team.team} label={team.team} value={`${team.wins}-${team.losses}`} sub={`Avg ${team.averageScore}, RR ${team.runRate}`} />)}</div>
      <section className="panel">
        <h2>Runs Trend</h2>
        <div className="chart">
          <ResponsiveContainer>
            <LineChart data={trend}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" hide />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="runs" stroke="#1f7a8c" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>
      <section className="panel">
        <DataTable headers={["Team", "Matches", "Wins", "Losses", "Runs", "High", "Low", "Extras"]} rows={teams.map((t) => [t.team, t.matches, t.wins, t.losses, t.runs, t.highest, t.lowest, t.extras])} />
      </section>
    </Page>
  );
}

function Upload() {
  const { state, addMatch } = useApp();
  const [preview, setPreview] = useState<Match | null>(null);
  const [message, setMessage] = useState("");
  const [duplicateMessage, setDuplicateMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function onFile(file?: File) {
    if (!file) return;
    setPreview(null);
    setDuplicateMessage("");
    setBusy(true);
    setMessage("");
    if (file.type && file.type !== "application/pdf") {
      setMessage("Please upload a PDF scorecard.");
      setBusy(false);
      return;
    }
    try {
      const pages = await extractPdfPages(file);
      const parsed = parseMatchFromPages(pages, file.name);
      const duplicate = findDuplicateMatch(state, parsed);
      if (duplicate) {
        setDuplicateMessage(`Already imported: ${duplicate.teamA} vs ${duplicate.teamB} on ${duplicate.matchDate ?? "unknown date"}.`);
      }
      setPreview(parsed);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not parse this PDF.");
    } finally {
      setBusy(false);
    }
  }

  function confirm() {
    if (!preview) return;
    try {
      addMatch(preview);
      setMessage("Match imported successfully.");
      setDuplicateMessage("");
      setPreview(null);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not save this match.");
    }
  }

  return (
    <Page title="Upload Scorecard">
      <section className="panel upload">
        <input type="file" accept="application/pdf" onChange={(event) => onFile(event.target.files?.[0])} />
        {busy && <p>Reading PDF...</p>}
        {message && <p className="notice">{message}</p>}
        {duplicateMessage && <p className="notice danger">{duplicateMessage}</p>}
      </section>
      {preview && (
        <section className="panel">
          <h2>Preview</h2>
          <p><strong>{preview.teamA} vs {preview.teamB}</strong></p>
          <p>{preview.matchDate} · {preview.ground}</p>
          <p>{preview.resultText}</p>
          <DataTable headers={["Team", "Score", "Overs"]} rows={preview.innings.map((i) => [i.battingTeam, `${i.totalRuns}/${i.totalWickets}`, i.overs])} />
          <button className="button" onClick={confirm} disabled={Boolean(duplicateMessage)}>Confirm import</button>
        </section>
      )}
    </Page>
  );
}

function Page({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <>
      <header className="pageHeader">
        <h1>{title}</h1>
        {action}
      </header>
      {children}
    </>
  );
}

function Metric({ icon, label, value, sub }: { icon?: React.ReactNode; label: string; value: React.ReactNode; sub?: string }) {
  return <section className="metric">{icon && <div className="metricIcon">{icon}</div>}<span>{label}</span><strong>{value}</strong>{sub && <small>{sub}</small>}</section>;
}

function DataTable({ headers, rows }: { headers: string[]; rows: Array<Array<React.ReactNode>> }) {
  const table = useMemo(() => ({ headers, rows }), [headers, rows]);
  return (
    <div className="tableWrap">
      <table>
        <thead><tr>{table.headers.map((header) => <th key={header}>{header}</th>)}</tr></thead>
        <tbody>{table.rows.map((row, index) => <tr key={index}>{row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <AppProvider>
        <Layout />
      </AppProvider>
    </BrowserRouter>
  </React.StrictMode>
);
